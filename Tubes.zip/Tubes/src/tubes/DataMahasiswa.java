package tubes;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Fahim Ahmad
 */
// DataMahasiswa.java
import java.util.Scanner;

public class DataMahasiswa extends Mahasiswa {

    // Implementasi metode dari interface
    @Override
    public void inputData() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Masukkan Nama: ");
        setNama(scanner.nextLine());

        System.out.print("Masukkan NIM: ");
        setNim(scanner.nextLine());

        System.out.print("Masukkan Tanggal Lahir: ");
        setTanggalLahir(scanner.nextLine());

        System.out.print("Masukkan Alamat: ");
        setAlamat(scanner.nextLine());

        System.out.print("Masukkan No. Telepon: ");
        setNoTelepon(scanner.nextLine());
    }

    // Implementasi metode dari interface
    @Override
    public void displayData() {
        System.out.println("\nDATA IDENTITAS MAHASISWA");
        System.out.println("Nama           : " + getNama());
        System.out.println("NIM            : " + getNim());
        System.out.println("Tanggal Lahir  : " + getTanggalLahir());
        System.out.println("Alamat         : " + getAlamat());
        System.out.println("No. Telepon    : " + getNoTelepon());
    }
}

