/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tubes;

/**
 *
 * @author Fahim Ahmad
 */
// Main.java
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;

        System.out.println("Program Data Identitas Mahasiswa");
        System.out.println("Dibuat oleh Fahim Ahmad\n");

        do {
            System.out.println("Menu:");
            System.out.println("1. Mulai Program");
            System.out.println("2. Exit");
            System.out.print("Pilih: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            switch (choice) {
                case 1 -> {
                    // Membuat objek DataMahasiswa
                    DataMahasiswa mahasiswa = new DataMahasiswa();
                    mahasiswa.inputData(); // Input data dari user
                    mahasiswa.displayData(); // Tampilkan data mahasiswa
                }
                case 2 -> System.out.println("Program selesai.");
                default -> System.out.println("Pilihan tidak valid. Silakan coba lagi.");
            }
        } while (choice != 2);
    }
}
